# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dl_scratch4',
 'dl_scratch4.ch01',
 'dl_scratch4.ch04',
 'dl_scratch4.ch05',
 'dl_scratch4.ch06',
 'dl_scratch4.ch07',
 'dl_scratch4.ch08',
 'dl_scratch4.ch09',
 'dl_scratch4.common',
 'dl_scratch4.pytorch']

package_data = \
{'': ['*'], 'dl_scratch4': ['notebooks/*']}

install_requires = \
['coloredlogs>=15.0.1,<16.0.0',
 'dezero>=0.0.13,<0.0.14',
 'jupyterlab>=3.4.2,<4.0.0',
 'matplotlib>=3.5.2,<4.0.0',
 'nptyping>=2.1.1,<3.0.0',
 'numpy>=1.22.4,<2.0.0',
 'opencv-python>=4.5.5,<5.0.0',
 'pandas>=1.4.2,<2.0.0',
 'plotly>=5.8.0,<6.0.0',
 'pytest>=7.1.2,<8.0.0',
 'rich>=12.4.4,<13.0.0',
 'scikit-learn>=1.1.1,<2.0.0',
 'scipy>=1.8.1,<2.0.0',
 'seaborn>=0.11.2,<0.12.0',
 'tensorflow-macos>=2.9.2,<3.0.0',
 'tqdm>=4.64.0,<5.0.0']

setup_kwargs = {
    'name': 'dl-scratch4',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Joichiro433',
    'author_email': 'joichiro322@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
